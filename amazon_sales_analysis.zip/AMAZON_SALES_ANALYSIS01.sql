-- creating the datatabse suing amazon dataset 
CREATE DATABASE amazon_sales;
USE amazon_sales;
-- creating columns for the amazon dataset 
CREATE TABLE sales_data (
invoice_id VARCHAR(30) PRIMARY KEY,
branch VARCHAR(5),
city VARCHAR(30),
customer_type VARCHAR(30),
gender VARCHAR(10),
product_line VARCHAR(100),
unit_price DECIMAL(10,2),
quantity INT,
VAT FLOAT(6,4),
total DECIMAL(10,2),
date DATE,
time TIMESTAMP,
payment_method VARCHAR(30),
cogs DECIMAL(10,2),
gross_margin_percentage FLOAT(11,9),
gross_income DECIMAL(10,2),
rating FLOAT(2,1)
);
-- loading the data in the clumns 
LOAD DATA INFILE "C:\Users\eshwa\OneDrive\Desktop\Amazon.csv"
INTO TABLE sales_data
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- finding the all records are available in the dataset
SELECT * FROM amazon_sales.amazon;

-- extracting the total sales from the dataset 
SELECT COUNT(*) AS total_sales FROM amazon;

-- Count of distinct cities
SELECT COUNT(DISTINCT City) AS distinct_cities FROM amazon;

-- Each branch and corresponding city
SELECT DISTINCT Branch, City FROM amazon;

-- Count of distinct product lines
SELECT COUNT(DISTINCT "Product line") AS distinct_product_lines FROM amazon;

-- Most frequent payment method
SELECT Payment, COUNT(*) AS frequency FROM amazon
GROUP BY Payment
ORDER BY frequency DESC
LIMIT 1;

-- Product line with highest sales
SELECT "Product line", SUM(Total) AS total_sales FROM amazon
GROUP BY "Product line"
ORDER BY total_sales DESC
LIMIT 1;

-- Revenue generated each month
SELECT FORMAT(Date, 'yyyy-MM') AS month, SUM(Total) AS revenue
FROM amazon
GROUP BY month
ORDER BY month;

-- Month with peak cost of goods sold
SELECT  FORMAT(Date, 'yyyy-MM') AS YearMonth, SUM(cogs) AS total_cogs
FROM amazon
GROUP BY YearMonth
ORDER BY total_cogs DESC
LIMIT 1;

-- Product line generating highest revenue
SELECT "Product line", SUM(Total) AS revenue FROM amazon
GROUP BY "Product line"
ORDER BY revenue DESC
LIMIT 1;

-- City with highest revenue
SELECT City, SUM(Total) AS revenue FROM amazon
GROUP BY City
ORDER BY revenue DESC
LIMIT 1;

-- Product line with highest VAT
SELECT "Product line", SUM("Tax 5%") AS total_vat FROM amazon
GROUP BY "Product line"
ORDER BY total_vat DESC
LIMIT 1;

-- Classifying product lines as Good or Bad based on average sales
SELECT *, 
       CASE WHEN Total > (SELECT AVG(Total) FROM amazon) THEN 'Good' ELSE 'Bad' END AS Sales_Class
FROM amazon;

-- Branch exceeding average number of products sold
SELECT Branch, SUM(Quantity) AS total_quantity FROM amazon
GROUP BY Branch
HAVING total_quantity > (SELECT AVG(Quantity) FROM amazon);

-- Most frequent product line by gender
SELECT Gender, "Product line", COUNT(*) AS frequency FROM amazon
GROUP BY Gender, "Product line"
ORDER BY Gender, frequency DESC;

-- Average rating per product line
SELECT "Product line", AVG(Rating) AS avg_rating FROM amazon
GROUP BY "Product line";

-- Customer type contributing highest revenue
SELECT "Customer type", SUM(Total) AS revenue FROM amazon
GROUP BY "Customer type"
ORDER BY revenue DESC
LIMIT 1;

-- City with highest VAT percentage
SELECT City, SUM("Tax 5%")/SUM(Total) AS vat_percentage FROM amazon
GROUP BY City
ORDER BY vat_percentage DESC
LIMIT 1;

-- Customer type with highest VAT payments
SELECT "Customer type", SUM("Tax 5%") AS total_vat FROM amazon
GROUP BY "Customer type"
ORDER BY total_vat DESC
LIMIT 1;

-- Count of distinct customer types
SELECT COUNT(DISTINCT "Customer type") AS distinct_customer_types FROM amazon;

-- Count of distinct payment methods
SELECT COUNT(DISTINCT Payment) AS distinct_payment_methods FROM amazon;

-- Most frequent customer type
SELECT "Customer type", COUNT(*) AS frequency FROM amazon
GROUP BY "Customer type"
ORDER BY frequency DESC
LIMIT 1;

-- Customer type with highest purchase frequency
SELECT "Customer type", COUNT(*) AS purchase_count FROM amazon
GROUP BY "Customer type"
ORDER BY purchase_count DESC
LIMIT 1;

-- Predominant gender among customers
SELECT Gender, COUNT(*) AS count FROM amazon
GROUP BY Gender
ORDER BY count DESC
LIMIT 1;

-- Gender distribution per branch
SELECT Branch, Gender, COUNT(*) AS count FROM amazon
GROUP BY Branch, Gender
ORDER BY Branch, count DESC;

-- Time of day with most ratings
SELECT format('%H', Time) AS hour, COUNT(Rating) AS rating_count FROM amazon
GROUP BY hour
ORDER BY rating_count DESC
LIMIT 1;

-- Time of day with highest ratings per branch
SELECT Branch, format('%H', Time) AS hour, AVG(Rating) AS avg_rating
FROM amazon
GROUP BY Branch, hour
ORDER BY Branch, avg_rating DESC;

-- Day of the week with highest average ratings
SELECT format('%w', Date) AS weekday, AVG(Rating) AS avg_rating FROM amazon
GROUP BY weekday
ORDER BY avg_rating DESC
LIMIT 1;

-- Day of the week with highest average ratings per branch
SELECT Branch, format('%w', Date) AS weekday, AVG(Rating) AS avg_rating
FROM amazon
GROUP BY Branch, weekday
ORDER BY Branch, avg_rating DESC;
